Load on demand angularjs module Example
=======================================

Install
-------

```bash
cd server
npm install
node server.js
```

Open your browser and type in the address bar http://localhost:3000/


# ionic-requirejs-starter
A starter template for ionic with requirejs

/**
 * Created by Osei Fortune on 7/2/15.
 */
angular.module('parse-starter.controllers',[]);